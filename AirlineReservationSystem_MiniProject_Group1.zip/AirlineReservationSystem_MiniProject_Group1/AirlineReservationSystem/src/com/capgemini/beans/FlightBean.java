package com.capgemini.beans;


public class FlightBean 
{
	private String FlightNO;
	private String AirLine;
	private String DepCity;
	private String ArrCity;
	private String DepDate;
	private String ArrDate;
	private String DepTime;
	private String ArrTime;
	private int FirstSeat;
	private int FirstSeatFare;
	private int BussSeat;
	private int BussSeatFare;

	public String getFlightNO() {
		return FlightNO;
	}

	public void setFlightNO(String flightNO) {
		FlightNO = flightNO;
	}

	public String getAirLine() {
		return AirLine;
	}

	public void setAirLine(String airLine) {
		AirLine = airLine;
	}

	public String getDepCity() {
		return DepCity;
	}

	public void setDepCity(String depCity) {
		DepCity = depCity;
	}

	public String getArrCity() {
		return ArrCity;
	}

	public void setArrCity(String arrCity) {
		ArrCity = arrCity;
	}

	public String getDepDate() {
		return DepDate;
	}

	public void setDepDate(String depDate) {
		DepDate = depDate;
	}

	public String getArrDate() {
		return ArrDate;
	}

	public void setArrDate(String arrDate) {
		ArrDate = arrDate;
	}

	public String getDepTime() {
		return DepTime;
	}

	public void setDepTime(String depTime) {
		DepTime = depTime;
	}

	public String getArrTime() {
		return ArrTime;
	}

	public void setArrTime(String arrTime) {
		ArrTime = arrTime;
	}

	public int getFirstSeat() {
		return FirstSeat;
	}

	public void setFirstSeat(int FirstSeat) {
		this.FirstSeat = FirstSeat;
	}

	public int getFirstSeatFare() {
		return FirstSeatFare;
	}

	public void setFirstSeatFare(int FirstSeatFare) {
		this.FirstSeatFare = FirstSeatFare;
	}

	public int getBussSeat() {
		return BussSeat;
	}

	public void setBussSeat(int bussSeat) {
		BussSeat = bussSeat;
	}

	public int getBussSeatFare() {
		return BussSeatFare;
	}

	public void setBussSeatFare(int bussSeatFare) {
		BussSeatFare = bussSeatFare;
	}

	@Override
	public String toString() {
		System.out.println("Airline Flight Reservation System: Flights Avaliable \n");
		
		return "FlightBean [FlightNO=" + FlightNO + ", AirLine=" + AirLine + ", DepCity=" + DepCity + ", ArrCity="
				+ ArrCity + ", DepDate=" + DepDate + ", ArrDate=" + ArrDate + ", DepTime=" + DepTime + ", ArrTime="
				+ ArrTime + ", FirstSeat=" + FirstSeat + ", FirstSeatFare=" + FirstSeatFare + ", BussSeat=" + BussSeat
				+ ", BussSeatFare=" + BussSeatFare + "]";
	}
	
}