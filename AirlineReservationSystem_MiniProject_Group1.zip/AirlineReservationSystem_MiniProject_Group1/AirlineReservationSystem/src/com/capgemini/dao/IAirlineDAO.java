package com.capgemini.dao;


import java.util.List;

import com.capgemini.beans.BookingBean;
import com.capgemini.beans.FlightBean;
import com.capgemini.exception.AirLineException;



public interface IAirlineDAO 
{

	public List<FlightBean> retriveAllDetails()throws AirLineException;
	public String addBookingDetails(BookingBean bookingBean) throws AirLineException;
	public BookingBean viewBookingDetails(String seatNumber) throws AirLineException;
	public String deleteBookingDetails(String seatNumber) throws AirLineException;
	public boolean updateBookingDetails(String bookingId,String custEmail,int noOfPassengers,String classType,int totalfare,String seatNumber,String creditCardInfo,String srcCity,String destCity) throws AirLineException;
	public boolean updateFlightDetails(String flightNo,String airLine,String depCity,String arrCity,String depDate,String arrDate,String depTime,String arrTime,int fristSeat,int fristSeatFare,int bussSeat,int bussSeatFare) throws AirLineException;
	public FlightBean viewflightDetails(String flightNO) throws AirLineException;
}
