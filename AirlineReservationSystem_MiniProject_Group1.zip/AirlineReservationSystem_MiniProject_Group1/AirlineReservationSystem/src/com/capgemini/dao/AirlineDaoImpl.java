package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.beans.BookingBean;
import com.capgemini.beans.FlightBean;
import com.capgemini.exception.AirLineException;
import com.capgemini.util.DBConnection;




public class AirlineDaoImpl implements IAirlineDAO 
{
	
	Logger logger=Logger.getRootLogger();
	public AirlineDaoImpl()
	{
	PropertyConfigurator.configure("log4j.properties");
	
	}
	


	public  List<FlightBean> retriveAllDetails()throws AirLineException {
		
		Connection con=DBConnection.getInstance().getConnection();
		int flightCount = 0;
		
		PreparedStatement ps=null;
		ResultSet resultset = null;
		
		List<FlightBean> flightList=new ArrayList<FlightBean>();
		try
		{
			ps=con.prepareStatement(QueryMapper.RETRIVE_ALL_QUERY);
			resultset=ps.executeQuery();
			
			while(resultset.next())
			{	
				FlightBean flightbean=new FlightBean();
				flightbean.setFlightNO((resultset.getString(1)));
				flightbean.setAirLine((resultset.getString(2)));
				flightbean.setDepCity((resultset.getString(3)));
				flightbean.setArrCity((resultset.getString(4)));
				flightbean.setDepDate((resultset.getString(5)));
				flightbean.setArrDate((resultset.getString(6)));
				flightbean.setDepTime((resultset.getString(7)));
				flightbean.setArrTime((resultset.getString(8)));
				flightbean.setFirstSeat((resultset.getInt(9)));
				flightbean.setFirstSeatFare((resultset.getInt(10)));
				flightbean.setBussSeat((resultset.getInt(11)));
				flightbean.setBussSeatFare((resultset.getInt(12)));
				flightList.add(flightbean);
				
				flightCount++;
			}			
			
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new AirLineException("Tehnical problem occured. Refer log");
		}
		
		finally
		{
			try 
			{
				resultset.close();
				ps.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new AirLineException("Error in closing db connection");

			}
		}
		
		if( flightCount == 0)
			return null;
		else
			return flightList;
	}

	@SuppressWarnings("resource")
	public String addBookingDetails(BookingBean bookingBean) throws AirLineException 
	{
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String SeatNumber=null;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			preparedStatement.setString(1,bookingBean.getBookingId());			
			preparedStatement.setString(2,bookingBean.getCustEmail());
			preparedStatement.setInt(3,bookingBean.getNoOfPassengers());
			preparedStatement.setString(4,bookingBean.getClassType());
			preparedStatement.setInt(5,bookingBean.getTotalfare());
			preparedStatement.setString(6,bookingBean.getCreditCardInfo());
			preparedStatement.setString(7,bookingBean.getSrcCity());
			preparedStatement.setString(8,bookingBean.getDestCity());
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.SEATNO_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				SeatNumber=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new AirLineException("Inserting booking details failed ");

			}
			else
			{
				logger.info("Booking details added successfully:");
				return SeatNumber;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new AirLineException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new AirLineException("Error in closing db connection");

			}
		}
		
		
	}	
	public BookingBean viewBookingDetails(String seatNumber) throws AirLineException {
		
		Connection connection=DBConnection.getInstance().getConnection();
		
		
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		BookingBean bookingBean=null;
		
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_BOOKING_DETAILS_QUERY);
			preparedStatement.setString(1,seatNumber);
			resultset=preparedStatement.executeQuery();
			
			if(resultset.next())
			{
				bookingBean = new BookingBean();
				bookingBean.setBookingId(resultset.getString(1));
				bookingBean.setCustEmail(resultset.getString(2));
				bookingBean.setNoOfPassengers(resultset.getInt(3));
				bookingBean.setClassType(resultset.getString(4));
				bookingBean.setTotalfare(resultset.getInt(5));
				bookingBean.setCreditCardInfo(resultset.getString(6));
				bookingBean.setSrcCity(resultset.getString(7));
				bookingBean.setDestCity(resultset.getString(8));
				
			}
			
			if( bookingBean != null)
			{
				logger.info("Record Found Successfully");
				return bookingBean;
			}
			else
			{
				logger.info("Record Not Found Successfully");
				return null;
			}
			
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
			throw new AirLineException(e.getMessage());
		}
		finally
		{
			try 
			{
				resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new AirLineException("Error in closing db connection");

			}
		}
		
	}
	public String deleteBookingDetails(String seatNumber) throws AirLineException {
		Connection connection=DBConnection.getInstance().getConnection();
		
        try{
        	PreparedStatement deletestatement1=connection.prepareStatement(QueryMapper.DELETE_BOOKING_DETAILS_QUERY);
          deletestatement1.setString(1, seatNumber);
   

          deletestatement1.executeQuery();
          System.out.println("\n BookingDetails "+seatNumber+" deleted");
          return seatNumber;

        } catch (SQLException e) {
			e.printStackTrace();
			
			return seatNumber;
        	
        }
	}

	public boolean updateBookingDetails(String bookingId,String custEmail,int noOfPassengers,String classType,int totalfare,String seatNumber,String creditCardInfo,String srcCity,String destCity) throws AirLineException{
		Connection connection=DBConnection.getInstance().getConnection();
		String updatequery= "update BookingInformation Set BookingId=?, CustEmail=?,NoOfPassengers=?, ClassType=?, TotalFare=?, CreditCardInfo=?, SrcCity=?, DestCity=?  WHERE SeatNumber=?";
			try{
				PreparedStatement updatestatement= connection.prepareStatement(updatequery);
				updatestatement.setString(1, bookingId );
				updatestatement.setString(2, custEmail);
				updatestatement.setInt(3, noOfPassengers );

				updatestatement.setString(4, classType);
				updatestatement.setInt(5, totalfare);
				
				updatestatement.setString(6, creditCardInfo);
				updatestatement.setString(7, srcCity);
				updatestatement.setString(8, destCity);
				updatestatement.setString(9, seatNumber);
				int rows = updatestatement.executeUpdate();
				if(rows > 0)
				{
					System.out.println("Program update created succesfully...");
					logger.info("program updated in db now...");
					return true;
				}
					
					
				else 
					return false;
				
			} catch (SQLException e) {
				e.printStackTrace();
				logger.error(e.getMessage());
				throw new AirLineException("Failed to update program");
				
			}

			
		}



	@Override
	public boolean updateFlightDetails(String flightNo, String airLine, String depCity, String arrCity, String depDate,
			String arrDate, String depTime, String arrTime, int FirstSeat, int FirstSeatFare, int bussSeat,
			int bussSeatFare) throws AirLineException {
		Connection connection=DBConnection.getInstance().getConnection();
		String updatequery= "update flightInformation Set airLine=?, depCity=?,arrCity=?, depDate=?, arrDate=?, depTime=?, arrTime=?, FirstSeat=?,FirstSeatFare=?,bussSeat=?,bussSeatFare=?  WHERE flightNo=?";
			try{
				PreparedStatement updatestatement= connection.prepareStatement(updatequery);
				
				updatestatement.setString(1, airLine);
				updatestatement.setString(2, depCity );

				updatestatement.setString(3, arrCity);
				updatestatement.setString(4,depDate);
				updatestatement.setString(5, arrDate);
				
				updatestatement.setString(6, depTime);
				updatestatement.setString(7, arrTime);
				updatestatement.setInt(8, FirstSeat);
				updatestatement.setInt(9, FirstSeatFare);
				updatestatement.setInt(10, bussSeat);
				updatestatement.setInt(11, bussSeatFare);
				updatestatement.setString(12, flightNo );
				int rows = updatestatement.executeUpdate();
				if(rows > 0)
				{
					System.out.println("Program update created succesfully...");
					logger.info("program updated in db now...");
					return true;
				}
					
					
				else 
					return false;
				
			} catch (SQLException e) {
				e.printStackTrace();
				logger.error(e.getMessage());
				throw new AirLineException("Failed to update program");
				
			}

	}
	
public FlightBean viewflightDetails(String flightNO) throws AirLineException {
		
		Connection connection=DBConnection.getInstance().getConnection();
		
		
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		FlightBean flightBean=null;
		
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_FLIGHT_DETAILS_QUERY);
			preparedStatement.setString(1,flightNO);
			resultset=preparedStatement.executeQuery();
			
			if(resultset.next())
			{
				flightBean = new FlightBean();
				flightBean.setAirLine(resultset.getString(1));
				flightBean.setDepCity(resultset.getString(2));
				flightBean.setArrCity(resultset.getString(3));
				flightBean.setDepDate(resultset.getString(4));
				flightBean.setArrDate(resultset.getString(5));
				flightBean.setDepTime(resultset.getString(6));
				flightBean.setArrTime(resultset.getString(7));
				flightBean.setFirstSeat(resultset.getInt(8));
				flightBean.setFirstSeatFare(resultset.getInt(9));
				flightBean.setBussSeat(resultset.getInt(10));
				flightBean.setBussSeatFare(resultset.getInt(11));
				
			}
			
			if( flightBean != null)
			{
				logger.info("Record Found Successfully");
				return flightBean;
			}
			else
			{
				logger.info("Record Not Found Successfully");
				return null;
			}
			
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
			throw new AirLineException(e.getMessage());
		}
		finally
		{
			try 
			{
				resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new AirLineException("Error in closing db connection");

			}
		}
		
	}
	
}
