package com.capgemini.service;



import java.util.List;


import com.capgemini.beans.BookingBean;
import com.capgemini.beans.FlightBean;
import com.capgemini.dao.AirlineDaoImpl;
import com.capgemini.dao.IAirlineDAO;
import com.capgemini.exception.AirLineException;


public class AirlineServiceImpl implements IAirlineService {
	
	IAirlineDAO airlineDao;

	public List<FlightBean> retriveAll()throws AirLineException {
		airlineDao=new AirlineDaoImpl();
		List<FlightBean> flightList=null;
		flightList=airlineDao.retriveAllDetails();
		return flightList;
	}

	public String addBookingDetails(BookingBean bookingBean) throws AirLineException {
		airlineDao=new AirlineDaoImpl();	
		String seatNumber;
		seatNumber= airlineDao.addBookingDetails(bookingBean);
		return seatNumber; 
	}


public String deleteBookingDetails(String seatNumber)throws AirLineException{
	airlineDao=new AirlineDaoImpl();
	String seatNumber1;
	seatNumber1= airlineDao.deleteBookingDetails(seatNumber);
	return seatNumber1;
	}

public BookingBean viewBookingDetails(String seatNumber) throws AirLineException {
	airlineDao=new AirlineDaoImpl();
	BookingBean bookingbean=null;
	bookingbean=airlineDao.viewBookingDetails(seatNumber);
	return bookingbean;
}



public boolean updateBookingDetails(String bookingId,String custEmail,int noOfPassengers,String classType,int totalfare,String seatNumber,String creditCardInfo,String srcCity,String destCity)throws AirLineException
{
	airlineDao=new AirlineDaoImpl();
	boolean a= airlineDao.updateBookingDetails(bookingId,custEmail, noOfPassengers, classType,totalfare,seatNumber, creditCardInfo,srcCity,destCity);
	return a;
}

public void validateBooking(BookingBean bookingBean)throws AirLineException {
	// TODO Auto-generated method stub
	
}

public boolean validateBookingId(String seatNumber)throws AirLineException {
	// TODO Auto-generated method stub
	return true;
}

@Override
public boolean updateFlightDetails(String flightNo, String airLine, String depCity, String arrCity, String depDate,
		String arrDate, String depTime, String arrTime, int fristSeat, int fristSeatFare, int bussSeat, int bussSeatFare)
		throws AirLineException {
	airlineDao=new AirlineDaoImpl();
	boolean a= airlineDao.updateFlightDetails(flightNo,airLine, depCity, arrCity,depDate,arrDate, depTime,arrTime,fristSeat,fristSeatFare,bussSeat,bussSeatFare);
	return a;
}


public FlightBean viewflightDetails(String flightNO) throws AirLineException {
	airlineDao=new AirlineDaoImpl();
	FlightBean flightBean=null;
	flightBean=airlineDao.viewflightDetails(flightNO);
	return flightBean;
}

public boolean validateFlightNO(String flightNO) throws AirLineException {
	// TODO Auto-generated method stub
	return true;
}




}
	