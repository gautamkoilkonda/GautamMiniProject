package com.capgemini.ui;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.beans.BookingBean;
import com.capgemini.beans.FlightBean;
import com.capgemini.exception.AirLineException;
import com.capgemini.service.AirlineServiceImpl;
import com.capgemini.service.IAirlineService;


public class main  {

	static Scanner sc = new Scanner(System.in);
	static IAirlineService airlineservice = null;
	static AirlineServiceImpl airlineService = null;
	static Logger logger = Logger.getRootLogger();
	
	public static void main(String[] args) {
		PropertyConfigurator.configure("log4j.properties");
		BookingBean bookingBean = null;
		String seatNumber = null;

		
		int option = 0;

		while (true) {
			

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("  Airline Reservation System");
			System.out.println("___________________________________________\n");

			System.out.println("1.View Flights ");
			System.out.println("2.Make a Reservation ");
			System.out.println("3.View or change booking Information ");
			System.out.println("4.Maintain Flight information ");
			System.out.println("5.View Flight Information ");
			System.out.println("6.Other Information ");
			System.out.println("7.Exit");
			System.out.println("____________________________________________");
			System.out.println("Select an option:");
			

			
				option = sc.nextInt();

				String flightNO =null;
				switch (option) {

				case 1:
				{
						airlineService = new AirlineServiceImpl();
					
					try {
						List<FlightBean> flightList = new ArrayList<FlightBean>();
						flightList = airlineService.retriveAll();

						if (flightList != null) {
							Iterator<FlightBean> i = flightList.iterator();
							while (i.hasNext()) {
							
								System.out.println(i.next());
							
							}
						} else {
							
							System.out.println("Flight Details not available");
						}

					}

					catch (AirLineException e) {

						System.out.println("Error  :" + e.getMessage());
					}

					break;

				}
				case 2:

					while (bookingBean == null) {
						bookingBean = populateBookingBean();
					
					}

					try {
						airlineservice = new AirlineServiceImpl();
						seatNumber = airlineservice.addBookingDetails(bookingBean);

						System.out
								.println("Booking details  has been successfully registered ");
						System.out.println("Your Seat Number Is: " + seatNumber);

					} catch (AirLineException airlineException) {
						logger.error("exception occured", airlineException);
						System.out.println("ERROR : "
								+ airlineException.getMessage());
					} finally {
						seatNumber = null;
						airlineservice = null;
						bookingBean = null;
					}

					break;
					

				case 3:
				{
					int choice = 0;
					System.out.println("1.View Booking ");
					System.out.println("2.Update Booking ");
					System.out.println("3.Delete Booking ");
					System.out.println("Select an option:");
					

					
					choice = sc.nextInt();
					

					switch (choice) {
					
					
					case 1: 

					airlineService = new AirlineServiceImpl();

					System.out.println("Enter SeatNumber:");
					seatNumber = sc.next();
					
					while (true) {
						try {
							if (airlineService.validateBookingId(seatNumber)) {
								break;
							} else {
								System.err
										.println("Please enter numeric SeatNumber only, try again");
								seatNumber = sc.next();
							}
						} catch (AirLineException e) {
							e.printStackTrace();
						}
					}

					bookingBean = getBookingDetails(seatNumber);

					if (bookingBean != null) {
						System.out.println("Booking Id		:"
								+ bookingBean.getBookingId());
						System.out.println("Customer Email		:"
								+ bookingBean.getCustEmail());
						System.out.println("Number Of Passengers		:"
								+ bookingBean.getNoOfPassengers());
						System.out.println("Class Type		:"
								+ bookingBean.getClassType());
						System.out.println("Total Fare		:"
								+ bookingBean.getTotalfare());
						System.out.println("Credit Card Information		:"
								+ bookingBean.getCreditCardInfo());
						System.out.println("Source City			:"
								+ bookingBean.getSrcCity());
						System.out.println("Destination City		:"
								+ bookingBean.getDestCity());
					} else {
						System.err
								.println("There are no booking details associated with seat number "
										+ seatNumber);
					}

					break;
					case 2:
						airlineService = new AirlineServiceImpl();

						System.out.println("Enter SeatNumber:");
						seatNumber = sc.next();
						while (true) {
							
							
							try {
							
							
	 		        	        if(seatNumber!=null){
	
	  		        	        System.out.println("\n BookingId: ");
	  		        	        String bookingId= sc.next();
	  		        	        
	  		        	        System.out.println("\n Customer Email: ");
	  		        	        String custEmail= sc.next();
	  		        	        
	  		        	        System.out.println("\n Number Of Passengers: ");
	  		        	        int noOfPassengers= sc.nextInt();
	  		        	        
	  		        	        System.out.println("\n ClassType(first seat/ business seat): ");
	  		        	        String classType= sc.next();
	  		        	      
	  		        	        System.out.println("\n Total Fare: ");
	  		        	        int totalfare= sc.nextInt();
	  		        	     
	  		        	        System.out.println("\n Credit Card Information: ");
	  		        	        String creditCardInfo= sc.next();
	  		        	        
	  		        	        System.out.println("\n Source City: ");
	  		        	        String srcCity= sc.next();
	  		        	        
	  		        	        System.out.println("\n Destination City: ");
	  		        	        String destCity= sc.next();
	 
							airlineService.updateBookingDetails(bookingId,custEmail, noOfPassengers, classType,totalfare,seatNumber, creditCardInfo,srcCity,destCity);  
					
									break;
								} else {
									System.err
											.println("Please enter numeric SeatNumber only, try again");
									seatNumber = sc.next();
								}
							} catch (AirLineException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
						
						break;
					case 3:

						airlineService = new AirlineServiceImpl();

						System.out.println("Enter SeatNumber:");
						seatNumber = sc.next();

						while (true) {
							try {
								if (airlineService.deleteBookingDetails(seatNumber) != null) {
									break;
								} else {
									System.err
											.println("Please enter numeric SeatNumber only, try again");
									seatNumber = sc.next();
								}
							} catch (AirLineException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}

						
					break;
					}
					break;
				}
				
				case 4:
				{

					int choice1 = 0;
					System.out.println("1.View flight ");
					System.out.println("2.Update flight ");
					System.out.println("3.Delete flight ");
					System.out.println("Select an option:");
					
					//FlightBean flightBean = null;
					String flightNo = null;
					choice1 = sc.nextInt();
					

					switch (choice1) {
					
					
					case 1: 

					{
						airlineService = new AirlineServiceImpl();
					
					try {
						List<FlightBean> flightList = new ArrayList<FlightBean>();
						flightList = airlineService.retriveAll();

						if (flightList != null) {
							Iterator<FlightBean> i = flightList.iterator();
							while (i.hasNext()) {
							
								System.out.println(i.next());
							
							}
						} else {
							
							System.out.println("Flight Details not available");
						}

					}

					catch (AirLineException e) {

						System.out.println("Error  :" + e.getMessage());
					}

					break;

				}
					case 2:
						
						airlineService = new AirlineServiceImpl();

						System.out.println("flightNo:");
						flightNo = sc.next();
						while (true) {
							
							
							try {
							
							
	 		        	        if(flightNo!=null){
	
	  		        	        System.out.println("\n AirLine: ");
	  		        	        String airLine= sc.next();
	  		        	        
	  		        	        System.out.println("\n Departure City: ");
	  		        	        String depCity= sc.next();
	  		        	        
	  		        	        System.out.println("\n Arrival City: ");
	  		        	        String arrCity= sc.next();
	  		        	        
	  		        	        System.out.println("\n Departure Date: ");
	  		        	        String depDate= sc.next();
	  		        	      
	  		        	        System.out.println("\n Arrival Date: ");
	  		        	        String arrDate= sc.next();
	  		        	        
	  		        	      System.out.println("\n Departure Time: ");
	  		        	        String depTime= sc.next();
	  		        	        
	  		        	      System.out.println("\n Arrival Time: ");
	  		        	        String arrTime= sc.next();
	  		        	     
	  		        	        System.out.println("\n First Seat: ");
	  		        	        int FirstSeat= sc.nextInt();
	  		        	        
	  		        	      System.out.println("\n First Seat Fare: ");
	  		        	        int FirstSeatFare= sc.nextInt();
	  		        	        
	  		        	      System.out.println("\n Business Seat: ");
	  		        	        int bussSeat= sc.nextInt();
	  		        	        
	  		        	      System.out.println("\n Business Seat Fare: ");
	  		        	        int bussSeatFare= sc.nextInt();
	 
							airlineService.updateFlightDetails(flightNo,airLine, depCity, arrCity,depDate,arrDate, depTime,arrTime,FirstSeat,FirstSeatFare,bussSeat,bussSeatFare);  
					
									break;
								} else {
									System.err
											.println("Please enter numeric SeatNumber only, try again");
									flightNo = sc.next();
								}
							} catch (AirLineException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
						
						break;
					case 3:

						airlineService = new AirlineServiceImpl();

						System.out.println("Enter SeatNumber:");
						flightNo = sc.next();

						while (true) {
							try {
								if (airlineService.deleteBookingDetails(flightNo) != null) {
									break;
								} else {
									System.err
											.println("Please enter numeric SeatNumber only, try again");
									flightNo = sc.next();
								}
							} catch (AirLineException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}

					
					break;
					}
					break;
				}
				
				case 5:
				{
					FlightBean flightBean = null;
					airlineService = new AirlineServiceImpl();

					System.out.println("Enter Flight Number:");
					flightNO = sc.next();
					
					while (true) {
						try {
							if (airlineService.validateFlightNO(flightNO)) {
								break;
							} else {
								System.err
										.println("Please enter numeric flight number only, try again");
								flightNO = sc.next();
							}
						} catch (AirLineException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					flightBean = getflightDetails(flightNO);
					if (flightBean != null) {
						
						System.out.println("Airline		:"
								+  flightBean.getAirLine());
						System.out.println("Departure City		:"
								+  flightBean.getDepCity());
						System.out.println("Arrival City		:"
								+  flightBean.getArrCity());
						System.out.println("Departure Date:"
								+  flightBean.getDepDate());
						System.out.println("Arrival Date		:"
								+ flightBean.getArrDate());
						System.out.println("Departure Time		:"
								+  flightBean.getDepTime());
						System.out.println("Arrival Time		:"
								+ flightBean.getArrTime());
						System.out.println("First Seat		:"
								+  flightBean.getFirstSeat());
						System.out.println("First Seat Fare		:"
								+  flightBean.getFirstSeatFare());
						System.out.println("Business Seat		:"
								+  flightBean.getBussSeat());
						System.out.println("Business Seat Fare		:"
								+ flightBean.getBussSeatFare());
					} else {
						System.err
								.println("There are no Flight is associated with Flight number "
										+ flightNO);
					}
					break;
				}
				case 6:
					System.out.print("________________________________________");
					System.out.print("\n GROUP MEMBER'S NAME");
					System.out.print("\n 1. Ankit Singh(Leader)");
					System.out.print("\n 2. Himanshu Srivastava");
					System.out.print("\n 3. Deepansh Soni");
					System.out.print("\n 4. Konda Nithej ");
					System.out.print("\n 5. Sai Chaitanya");
					System.out.print("\n 6. K.Gautam");
					System.out.print("\n Contact No:8630921962");
					System.out.print("\n Address: Room.No:F102,Capgemini Talawade\n");
					System.out.print("________________________________________");
						
					break;
				case 7:

					System.exit(0);
				default:
					System.out.println("Enter a valid option[1-7]");	
				
					
					
				}
				
				}
		}
		
			
	
		
	

	private static FlightBean getflightDetails(String flightNO) {
		FlightBean flightBean = null;
		airlineService = new AirlineServiceImpl();

		try {
			flightBean = airlineService.viewflightDetails(flightNO);
		} catch (AirLineException airlineException) {
			logger.error("exception occured ", airlineException);
			System.out.println("ERROR : " +airlineException.getMessage());
		}

		airlineService = null;
		return flightBean;
	}






	private static BookingBean getBookingDetails(String seatNumber) {
		BookingBean bookingBean = null;
		airlineService = new AirlineServiceImpl();

		try {
			bookingBean = airlineService.viewBookingDetails(seatNumber);
		} catch (AirLineException airlineException) {
			logger.error("exception occured ", airlineException);
			System.out.println("ERROR : " +airlineException.getMessage());
		}

		airlineService = null;
		return bookingBean;
	}
	

	private static BookingBean populateBookingBean() {
		BookingBean bookingBean = new BookingBean();;

		System.out.println("\n Enter Details");

		System.out.println("Enter ID : ");
		bookingBean.setBookingId((sc.next()));

		System.out.println("Enter email: ");
		bookingBean.setCustEmail(sc.next());

		System.out.println("Enter NoOfPass: ");
		bookingBean.setNoOfPassengers((sc.nextInt()));
		
		System.out.println("Enter Class: ");
		bookingBean.setClassType(sc.next());
		
		System.out.println("Enter CreditCardInfo: ");
		bookingBean.setCreditCardInfo(sc.next());
		
		System.out.println("Enter SrcCity: ");
		bookingBean.setSrcCity(sc.next());
		
		System.out.println("Enter DestCity: ");
		bookingBean.setDestCity(sc.next());


		System.out.println("Enter Totalfare ");

		try {
			bookingBean.setTotalfare(sc.nextInt());
		} catch (InputMismatchException inputMismatchException) {
			sc.nextLine();
			System.err
					.println("Please enter a numeric value for Total amount, try again");
			}
		airlineService = new AirlineServiceImpl();

		try {
			airlineService.validateBooking(bookingBean);
			return bookingBean;
		} catch (AirLineException airlineException) {
			logger.error("exception occured", airlineException);
			System.err.println("Invalid data:");
			System.err.println(airlineException.getMessage() + " \n Try again..");
			System.exit(0);

		}
	
		return null;
	}
	
	
}
	
