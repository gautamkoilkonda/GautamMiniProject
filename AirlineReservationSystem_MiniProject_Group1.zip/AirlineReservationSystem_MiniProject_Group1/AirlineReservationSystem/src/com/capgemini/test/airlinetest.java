
package com.capgemini.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.capgemini.beans.BookingBean;
import com.capgemini.dao.AirlineDaoImpl;
import com.capgemini.dao.IAirlineDAO;
import com.capgemini.exception.AirLineException;
import com.capgemini.service.AirlineServiceImpl;
import com.capgemini.service.IAirlineService;

import junit.framework.Assert;

public class airlinetest {
	
	
	
	@Test
	public void testInsert(){
		BookingBean s1= new BookingBean();
		s1.setBookingId("1");
		s1.setCustEmail("cap@capgemini.com");
		s1.setNoOfPassengers(3);
		s1.setClassType("Business");
		s1.setTotalfare(10000);
		s1.setSeatNumber("6");
		s1.setCreditCardInfo("1234567890");
		s1.setSrcCity("Pune");
		s1.setDestCity("Kolkata");
		
		IAirlineDAO dao= new AirlineDaoImpl();
		try {
			@SuppressWarnings("unused")
			String s=dao.addBookingDetails(s1);
			Assert.assertNotSame(0,s1.getBookingId());
		} catch (AirLineException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}	
	@Test(expected=AirLineException.class)
	public void testInsertForInvalidCourseCode() throws AirLineException{
		BookingBean s1= new BookingBean();
		s1.setBookingId("1");;
		s1.setCustEmail("cap@capgemini.com");
		s1.setNoOfPassengers(100);
		s1.setClassType("Business");
		s1.setTotalfare(100);
		s1.setSeatNumber("6");
		s1.setCreditCardInfo("1234569870");
		s1.setSrcCity("Pune");
		s1.setDestCity("Kolkata");
		IAirlineDAO dao= new AirlineDaoImpl();
		@SuppressWarnings("unused")
		String s=dao.addBookingDetails(s1);
	}
	

}